package com.example.chartmp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.charts.Chart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.ChartData;
import com.github.mikephil.charting.data.CombinedData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private LineChart chart1,chart2,chart3;
    private final int count = 13;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Android MPChart");
        setGraphs();
    }

    public void setGraphs()
    {
        setGraph1();
        setGraph2();
        setGraph3();
    }

    private void setGraph1()
    {
        chart1 = findViewById(R.id.lineChart1);
        chart1.getDescription().setEnabled(false);
        chart1.setBackgroundColor(Color.rgb(17,26,73));
        chart1.getAxisRight().setEnabled(false);
        chart1.getAxisLeft().setEnabled(false);
        XAxis xAxis = chart1.getXAxis();
        xAxis.setTextSize(10f);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setAxisLineColor(Color.WHITE);
        xAxis.setAxisLineWidth(2f);
        xAxis.setTextColor(Color.rgb(17,26,73));
//        xAxis.setDrawAxisLine(false);
        xAxis.setDrawGridLines(false);
        chart1.getLegend().setEnabled(false);

        List<Integer> colorList = new ArrayList<Integer>();
        colorList.add(Color.YELLOW);
        colorList.add(Color.GREEN);
        colorList.add(Color.RED);
        colorList.add(Color.WHITE);
        chart1.setData(DataGenerator.getLineData(20,colorList));
        chart1.invalidate();
    }

    private void setGraph2()
    {
        chart2 = findViewById(R.id.lineChart2);
        chart2.getDescription().setEnabled(false);
        chart2.setBackgroundColor(Color.rgb(17,26,73));
        chart2.getAxisRight().setEnabled(false);
        chart2.getAxisLeft().setEnabled(false);
        XAxis xAxis = chart2.getXAxis();
        xAxis.setTextSize(10f);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setAxisLineColor(Color.WHITE);
        xAxis.setAxisLineWidth(2f);
        xAxis.setTextColor(Color.rgb(17,26,73));
//        xAxis.setDrawAxisLine(false);
        xAxis.setDrawGridLines(false);
        chart2.getLegend().setEnabled(false);

        List<Integer> colorList = new ArrayList<Integer>();
        colorList.add(Color.YELLOW);
        colorList.add(Color.GREEN);
        colorList.add(Color.RED);
        chart2.setData(DataGenerator.getLineData(20,colorList));

        chart2.invalidate();
    }

    private void setGraph3()
    {
        chart3 = findViewById(R.id.lineChart3);
        chart3.getDescription().setEnabled(false);
        chart3.setBackgroundColor(Color.rgb(17,26,73));
        chart3.getAxisRight().setEnabled(false);
        chart3.getAxisLeft().setEnabled(false);
        XAxis xAxis = chart3.getXAxis();
        xAxis.setTextSize(10f);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setAxisLineColor(Color.WHITE);
        xAxis.setAxisLineWidth(2f);
        xAxis.setTextColor(Color.rgb(17,26,73));
//        xAxis.setDrawAxisLine(false);
        xAxis.setDrawGridLines(false);
        chart3.getLegend().setEnabled(false);

        List<Integer> colorList = new ArrayList<Integer>();
        colorList.add(Color.YELLOW);
        colorList.add(Color.GREEN);
        colorList.add(Color.RED);
        chart3.setData(DataGenerator.getLineData(20,colorList));

        chart3.invalidate();
    }

    /*
    private LineData generateLineData() {
        LineData d = new LineData();

        ArrayList<Entry> entries1 = new ArrayList<>();
        ArrayList<Entry> entries2 = new ArrayList<>();

        for (int index = 0; index < count; index++) {
            entries1.add(new Entry(index + 0.25f, getRandom(25, 15)));
            entries2.add(new Entry(index + 0.25f, getRandom(25, 12)));
        }

        LineDataSet set1 = new LineDataSet(entries1, "Line DataSet1");
        set1.setLabel("");
        set1.setColor(Color.rgb(240, 238, 70));
        set1.setLineWidth(2.5f);
        set1.setCircleColor(Color.rgb(240, 238, 70));
//        set1.setCircleRadius(0.1f);
        set1.setDrawCircles(false);
        set1.setFillColor(Color.rgb(240, 238, 70));
        set1.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set1.setDrawValues(false);
        set1.setValueTextSize(10f);
        set1.setValueTextColor(Color.rgb(240, 238, 70));


        LineDataSet set2 =new LineDataSet(entries2,"Line DataSet2");
        set2.setColor(Color.rgb(240, 238, 70));
        set2.setLineWidth(2.5f);
        set2.setCircleColor(Color.rgb(240, 238, 70));
        set2.setDrawCircles(false);
//        set2.setCircleRadius(0.1f);
        set2.setFillColor(Color.rgb(240, 238, 70));
        set2.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set2.setDrawValues(false);
        set2.setValueTextSize(10f);
        set2.setValueTextColor(Color.rgb(240, 238, 70));




//        LineDataSet set3 =new LineDataSet(entries2,"Line DataSet2");
//        set2.setColor(Color.rgb(240, 238, 70));
//        set2.setLineWidth(2.5f);
//        set2.setCircleColor(Color.rgb(240, 238, 70));
//        set2.setCircleRadius(5f);
//        set2.setFillColor(Color.rgb(240, 238, 70));
//        set2.setMode(LineDataSet.Mode.CUBIC_BEZIER);
//        set2.setDrawValues(true);
//        set2.setValueTextSize(10f);
//        set2.setValueTextColor(Color.rgb(240, 238, 70));




//        LineDataSet set4 =new LineDataSet(entries2,"Line DataSet2");
//        set2.setColor(Color.rgb(240, 238, 70));
//        set2.setLineWidth(2.5f);
//        set2.setCircleColor(Color.rgb(240, 238, 70));
//        set2.setCircleRadius(5f);
//        set2.setFillColor(Color.rgb(240, 238, 70));
//        set2.setMode(LineDataSet.Mode.CUBIC_BEZIER);
//        set2.setDrawValues(true);
//        set2.setValueTextSize(10f);
//        set2.setValueTextColor(Color.rgb(240, 238, 70));*

        //d.addDataSet(set1);
        //d.addDataSet(set2);
      //  d.addDataSet(set3);
        //d.addDataSet(set4);
//        chart.setData(d);
       // chart.invalidate();

       // return d;


    }

    */


}





