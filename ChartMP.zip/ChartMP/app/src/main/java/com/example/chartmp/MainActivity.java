package com.example.chartmp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.charts.Chart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.ChartData;
import com.github.mikephil.charting.data.CombinedData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private LineChart chart;
    private final int count = 13;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("Android MPChart");
        chart = findViewById(R.id.lineChart);

        chart.getDescription().setEnabled(false);
        chart.setBackgroundColor(Color.BLUE);
        //chart.setDrawGridBackground(false);

        CombinedData data = new CombinedData();

         data.setData(generateLineData());


       chart.invalidate();

    }

    private float getRandom(float range, float start) {
        return (float) (Math.random() * range) + start;
    }


    private LineData generateLineData() {
        LineData d = new LineData();

        ArrayList<Entry> entries1 = new ArrayList<>();
        ArrayList<Entry> entries2 = new ArrayList<>();
        // ArrayList<Entry> entries3 = new ArrayList<>();
        //  ArrayList<Entry> entries4 = new ArrayList<>();

        for (int index = 0; index < count; index++) {
            entries1.add(new Entry(index + 0.25f, getRandom(25, 15)));
            entries2.add(new Entry(index + 0.25f, getRandom(25, 12)));
    }



           // entries3.add(new Entry(index + 0.5f, getRandom(45, 20)));
            //entries4.add(new Entry(index + 0.5f, getRandom(50, 30)));





        LineDataSet set1 = new LineDataSet(entries1, "Line DataSet1");
        set1.setColor(Color.rgb(240, 238, 70));
        set1.setLineWidth(2.5f);
        set1.setCircleColor(Color.rgb(240, 238, 70));
        set1.setCircleRadius(5f);
        set1.setFillColor(Color.rgb(240, 238, 70));
        set1.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set1.setDrawValues(true);
        set1.setValueTextSize(10f);
        set1.setValueTextColor(Color.rgb(240, 238, 70));


        LineDataSet set2 =new LineDataSet(entries2,"Line DataSet2");
        set2.setColor(Color.rgb(240, 238, 70));
        set2.setLineWidth(2.5f);
        set2.setCircleColor(Color.rgb(240, 238, 70));
        set2.setCircleRadius(5f);
        set2.setFillColor(Color.rgb(240, 238, 70));
        set2.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set2.setDrawValues(true);
        set2.setValueTextSize(10f);
        set2.setValueTextColor(Color.rgb(240, 238, 70));




       /* LineDataSet set3 =new LineDataSet(entries2,"Line DataSet2");
        set2.setColor(Color.rgb(240, 238, 70));
        set2.setLineWidth(2.5f);
        set2.setCircleColor(Color.rgb(240, 238, 70));
        set2.setCircleRadius(5f);
        set2.setFillColor(Color.rgb(240, 238, 70));
        set2.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set2.setDrawValues(true);
        set2.setValueTextSize(10f);
        set2.setValueTextColor(Color.rgb(240, 238, 70));*/




       /* LineDataSet set4 =new LineDataSet(entries2,"Line DataSet2");
        set2.setColor(Color.rgb(240, 238, 70));
        set2.setLineWidth(2.5f);
        set2.setCircleColor(Color.rgb(240, 238, 70));
        set2.setCircleRadius(5f);
        set2.setFillColor(Color.rgb(240, 238, 70));
        set2.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set2.setDrawValues(true);
        set2.setValueTextSize(10f);
        set2.setValueTextColor(Color.rgb(240, 238, 70));*/

        d.addDataSet(set1);
        d.addDataSet(set2);
      //  d.addDataSet(set3);
        //d.addDataSet(set4);
        chart.setData(d);
       // chart.invalidate();

        return d;


    }


}





