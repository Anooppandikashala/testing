package com.example.chartmp;

import android.graphics.Color;

import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;
import java.util.List;

public class DataGenerator {
    private static float getRandom(float range, float start) {
        return (float) (Math.random() * range) + start;
    }

    public static LineData getLineData(int numberOfDataPoints, List<Integer> colors)
    {
        LineData d = new LineData();
        ArrayList<Entry> entries = new ArrayList<>();
        for(int i=0; i<colors.size(); i++) {
            if (i == 0) {
                for (int index = 0; index < numberOfDataPoints; index++) {
                    entries.add(new Entry(index + 0.25f, getRandom(25, 12)));
                }
            }
            ArrayList<Entry> tempEntry = new ArrayList<>();

            float randYVal = getRandom(10,-3);
            int c =0;
            for (Entry e : entries) {
                tempEntry.add(new Entry(e.getX(), ( c%3 ==0 ? e.getY() + randYVal : e.getY() - randYVal)));
                c++;
            }

            LineDataSet set = new LineDataSet(tempEntry, "");
            set.setLabel("");
            set.setColor(colors.get(i));
            set.setLineWidth(2.5f);
//            set.setCircleColor(colors.get(i));
            set.setDrawCircles(false);
            set.setFillColor(colors.get(i));
            set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
            set.setDrawValues(false);
            set.setValueTextSize(10f);
            set.setValueTextColor(Color.WHITE);
            set.setValueTextColor(colors.get(i));
            d.addDataSet(set);
        }
        return d;
    }


}
